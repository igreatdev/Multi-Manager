<?php
// app/Controller/UsersController.php
App::uses('AppController', 'Controller');

class UsersController extends AppController {

   public function beforeFilter() {
        parent::beforeFilter();
        // Allow users to register and logout.
        $this->Auth->allow('add', 'logout');
    }
    
    public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    if($user['role']==='B Manager'){
                        return $this->redirect(
                            array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                        );
                    }else if($user['role']==='POS'){
                        return $this->redirect(
                            array('BranchA'=>true, 'controller'=>'sales', 'action'=>'add')
                        );
                    }
                }
    }

    public function login() {
        $this->layout = 'login';
        if ($this->request->is('post')) {            
            if ($this->Auth->login()) {
                return $this->userRedirect();                
            }
            $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
            Invalid username or password, try again'), 'default', array('class'=>'alert alert-error'));
        }
    }

    public function logout() {
        return $this->redirect($this->Auth->logout());
    }

    public function index() {
        $this->User->recursive = 0;
        $this->set('users', $this->paginate());
    }

    public function profile($id = null) {
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        $this->set('user', $this->User->read(null, $id));
    }

    public function add() {
        if ($this->request->is('post')) {
            $this->User->create();
            if ($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Success</strong> The user has been saved'), 'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'login'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The user could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }

    public function Warehouse_edit($id = null) {
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('The user has been saved'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('The user could not be saved. Please, try again.')
            );
        } else {
            $this->request->data = $this->User->read(null, $id);
            unset($this->request->data['User']['password']);
        }
    }

    public function delete($id = null) {
        // Prior to 2.5 use
        // $this->request->onlyAllow('post');

        $this->request->allowMethod('post');

        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        if ($this->User->delete()) {
            $this->Session->setFlash(__('User deleted'));
            return $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('User was not deleted'));
        return $this->redirect(array('action' => 'index'));
    }
    
    public function Warehouse_dashboard() {
        $this->set('title_for_layout','Dashboard');
    }
    
    public function Warehouse_accdashboard() {
        $this->set('title_for_layout','Dashboard');
    }
    
    public function Warehouse_add() {
        if ($this->request->is('post')) {
            $this->User->create();
            $data = $this->request->data;
            
            $user = $this->User->find('first',array('conditions'=>array('User.username'=>$data['User']['username'])));
            if (empty($user)){
               if ($this->User->save($data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Success</strong> The user has been saved'), 'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'add'));
                }
            }else{
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The user could not be saved. User Already Exists.'), 'default', array('class'=>'alert alert-error')
                );
                
            }
            
        }
    }
    
    public function Warehouse_view() {
        $this->set('users', $this->User->find('all'));
    }
    // /! Warehouse
    
    public function BranchA_add() {
        if ($this->request->is('post')) {
            $this->User->create();
            $data = $this->request->data;
            
            $user = $this->User->find('first',array('conditions'=>array('User.username'=>$data['User']['username'])));
            if (empty($user)){
               if ($this->User->save($data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Success</strong> The user has been saved'), 'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'add'));
                }
            }else{
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The user could not be saved. User Already Exists.'), 'default', array('class'=>'alert alert-error')
                );
                
            }
            
        }
    }

    public function BranchA_edit($id = null) {
        $this->User->id = $id;
        if (!$this->User->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('The user has been saved'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('The user could not be saved. Please, try again.')
            );
        } else {
            $this->request->data = $this->User->read(null, $id);
            unset($this->request->data['User']['password']);
        }
    }
    
    public function BranchA_view() {
        $this->set('users', $this->User->find('all',array('conditions'=>array('User.Office'=>'BranchA'))));
    }
    
    public function BranchA_dashboard() {
        $this->set('title_for_layout','Dashboard');
    }
    
    public function BranchB_dashboard() {
        $this->set('title_for_layout','Dashboard');
    }
    
    public function documentation() {
        $this->set('title_for_layout','Documentation');
    }

}
?>