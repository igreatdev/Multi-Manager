<?php
// app/controller/SuppliesController

App::uses('AppController','Controller');

class SuppliesController extends AppController {
    public $uses = array('Supply','BranchaInventory','BranchbInventory','Product','ReturnedSupply','ProductCategory','Batch');
    
    public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    return $this->redirect(
                        array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchB'){
                    return $this->redirect(
                        array('BranchB'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $router = Router::parse(Router::normalize(Router::url()));
        $user = $this->Auth->user();
        if(!($user['Office']==$router['prefix'])){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                Warning! Invalid Access Area.'), 'default', array('class'=>'alert alert-warning')
            );
            $this->userRedirect();
        }
    }
    
    public function Warehouse_add() {
        $this->set('prodlist', $this->Product->find('list',array('fields'=>array('Product.Item'))));
        $this->set('category', $this->ProductCategory->find('list',array('fields'=>array('ProductCategory.Category'))));
                        
        if ($this->request->is('post') || $this->request->is('put')) {
            if(isset($this->request->data['Item'])){
                $data = $this->request->data;
                print_r($data);
                $items = $this->request->data['Item'];
                $flmsg = '';
                if($data['Branch']=='BranchA'){
                 foreach($items as $item){
                    $item['Date'] = $data['Date'];
                    $item['Branch'] = $data['Branch'];
                    $item['User'] = $data['User'];
                
                    $prod = $this->Batch->read(null,$item['Batch_id']);
                    
                    if($item['Quantity'] > $prod['Batch']['Quantity']){
                        $msg = '<div class="alert alert-error"> <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <b>Error!</b> The Quantity Supply for <b>'.$prod['Product']['Item'].'</b> is greater than available quantity. <br />';
                    }else{
                         $this->Supply->id = null;
                          if ($this->Supply->save($item)) {
                              $msg = '<div class="alert alert-success"> <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <b>Success.</b> The Supply for <b>'.$prod['Product']['Item'].'</b> has been Saved. <br />';
                              
                              $newdata = array();
                              $newdata['Product']['Quantity'] = $prod['Batch']['Quantity'] - $item['Quantity'];
                              $this->Batch->id = $prod['Batch']['id'];
                              if($this->Batch->save($newdata['Product'])){
                                  $msg .= '<b>Success.</b> The Batch Quantity has been updated. <br />';
                              }else{
                                  $msg .= '<b>Error!</b> The Batch Quantity could not be updated. <br />';
                              }
                              
                              $item['LastSupply'] = $item['Date'];
                              
                              if($this->BranchaInventory->hasAny(array('BranchaInventory.Product_id'=>$item['Product_id'],'BranchaInventory.Batch_id'=>$item['Batch_id']))){
                                $prodb = $this->BranchaInventory->find('first',array('conditions'=>array('BranchaInventory.Product_id'=>$item['Product_id'],'BranchaInventory.Batch_id'=>$item['Batch_id'])));
                              
                                $item['Quantity'] = $prodb['BranchaInventory']['Quantity'] + $item['Quantity'];
                                $this->BranchaInventory->id = $prodb['BranchaInventory']['id'];                              
                              }                              
                              
                              if($this->BranchaInventory->save($item)){
                                  $msg .= '<b>Success.</b> The Branch Inventory Quantity has been updated. <br />';
                              }else{
                                  $msg .= '<b>Error!</b> The Branch Inventory Quantity could not be updated. <br />';
                              }
                              $msg .= '</div>';
                                                                                                                        
                          }
                    }
                    $flmsg .= $msg;
                
                }   
                }elseif($data['Branch']=='BranchB'){
                foreach($items as $item){
                    $item['Date'] = $data['Date'];
                    $item['Branch'] = $data['Branch'];
                    $item['User'] = $data['User'];
                
                    $prod = $this->Product->read(null,$item['ItemId']);
                    if($item['Quantity'] > $prod['Product']['Quantity']){
                        $msg = '<div class="alert alert-error"> <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <b>Error!</b> The Quantity Supply for <b>'.$item['Item'].'</b> is greater than available quantity. <br />';
                    }else{
                        $this->Supply->id = null;
                        if ($this->Supply->save($item)) {
                            $msg = '<div class="alert alert-success"> <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <b>Success.</b> The Supply for <b>'.$item['Item'].'</b> has been Saved. <br />';
                            $newdata = array();
                            $newdata['Product']['Quantity'] = $prod['Product']['Quantity'] - $item['Quantity'];
                            $prodb = $this->BranchbInventory->find('first',array('conditions'=>array('BranchbInventory.Item'=>$item['Item'])));
                            $newdata['Item']['Quantity'] = $prodb['BranchbInventory']['Quantity'] + $item['Quantity'];
                            $newdata['Item']['Price'] = $item['Price'];
                            $newdata['Item']['LastSupply'] = $item['Date'];
                            $this->Product->id = $prod['Product']['id'];
                            $this->BranchbInventory->id = $prodb['BranchbInventory']['id'];
                            if($this->Product->save($newdata['Product'])){
                                $msg .= '<b>Success.</b> The Product Quantity has been updated. <br />';
                            }else{
                                $msg .= '<b>Error!</b> The Product Quantity could not be updated. <br />';
                            }
                            if($this->BranchbInventory->save($newdata['Item'])){
                                $msg .= '<b>Success.</b> The Branch Product Quantity has been updated. <br />';
                            }else{
                                $msg .= '<b>Error!</b> The Branch Product Quantity could not be updated. <br />';
                            }
                            $msg .= '</div>';
                                                                                                                      
                        }
                    }
                    $flmsg .= $msg;
                
                }
                }                               
                
                $this->Session->setFlash(__($flmsg));
                $this->redirect(array('action'=>'add'));
            }
                                    
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Purchase could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function Warehouse_view() {
        $this->set('supplies', $this->Supply->find('all'));
    }
            
    public function Warehouse_view_returned() {
        $this->set('supplies', $this->ReturnedSupply->find('all'));
    }
    
    public function Warehouse_report($Branch) {
        if ($this->request->is('post') || $this->request->is('put')) {
            if($Branch=='BranchA'){
            $data = $this->request->data;
            $from = implode('-',array($data['Supply']['From']['year'],$data['Supply']['From']['month'],$data['Supply']['From']['day']));
            $to = implode('-',array($data['Supply']['To']['year'],$data['Supply']['To']['month'],$data['Supply']['To']['day']));
            
            $reports = $this->Supply->find('all',array('conditions'=>array('Supply.Date BETWEEN ? AND ?'=>array($from,$to), 'Supply.Branch'=>'BranchA')));
            if(count($reports)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('reports',$reports);
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
            }
           }elseif($Branch=='BranchB'){
            $data = $this->request->data;
            $from = implode('-',array($data['Supply']['From']['year'],$data['Supply']['From']['month'],$data['Supply']['From']['day']));
            $to = implode('-',array($data['Supply']['To']['year'],$data['Supply']['To']['month'],$data['Supply']['To']['day']));
            
            $reports = $this->Supply->find('all',array('conditions'=>array('Supply.Date BETWEEN ? AND ?'=>array($from,$to), 'Supply.Branch'=>'BranchB')));
            if(count($reports)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('reports',$reports);
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
            }
           } 
        }
    }
    
    // ! Warehouse --
    
    // **BranchA ...
    
    public function Brancha_view() {
        $this->set('supplies', $this->Supply->find('all',array('conditions'=>array('Supply.Branch'=>'BranchA'))));
    }
    
    public function Brancha_returned($id=null) {
            if ($this->request->is('post') || $this->request->is('put')) {
                $this->Supply->id = $this->request->data['Supply']['id'];
                if (!$this->Supply->exists()) {
                    $this->Session->setFlash(
                        __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                        Invalid supply id = '.$id.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                    );
                }elseif($p = $this->Supply->find('first', array('conditions'=>array('Supply.id'=>$this->request->data['Supply']['id'],'Supply.Branch'=>'BranchA')))){
                    $this->set('supplyi', $p);
                }else{
                    $this->Session->setFlash(
                        __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                        Supply id = '.$id.' is not for this branch. Please, try again.'), 'default', array('class'=>'alert alert-error')
                    );
                }              
            }
    }
    
    public function Brancha_returnedsupply(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->ReturnedSupply->create();
            if ($this->ReturnedSupply->save($this->request->data['Supply'])) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Returned Purchase has been Saved. <br />';
                $this->Product->id = $this->request->data['Supply']['Item'];
                $prod = $this->Product->read();
                $prodb = $this->BranchaInventory->find('first',array('conditions'=>array('BranchaInventory.Item'=>$prod['Product']['Item'])));
                $newdata = array();
                $newdata['Product']['Quantity'] = $prod['Product']['Quantity'] + $this->request->data['Supply']['Quantity'];
                $newdata['Item']['Quantity'] = $prodb['BranchaInventory']['Quantity'] - $this->request->data['Supply']['Quantity'];
                $this->BranchaInventory->id = $prodb['BranchaInventory']['id'];
                if($this->Product->save($newdata['Product'])){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated. <br />';
                }else{
                    $msg .= '<b>Error!</b> The Product Quantity could not be updated. <br />';
                }
                if($this->BranchaInventory->save($newdata['Item'])){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated in Inventory. <br />';
                }else{
                    $msg .= '<b>Error!</b> The Product Quantity could not be updated in Inventory. <br />';
                }
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                $this->redirect(array('action'=>'returned'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Purchase could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function Brancha_view_returned() {
        $this->set('supplies', $this->ReturnedSupply->find('all',array('conditions'=>array('ReturnedSupply.Branch'=>'BranchA'))));
    }
    
    public function Brancha_inventory() {
        $this->set('inventories', $this->BranchaInventory->find('all'));
    }
    
    // ! BranchA --
    
    // **BranchB ...
    
    public function Branchb_view() {
        $this->set('supplies', $this->Supply->find('all',array('conditions'=>array('Supply.Branch'=>'BranchB'))));
    }
    
    public function Branchb_returned($id=null) {
            if ($this->request->is('post') || $this->request->is('put')) {
                $this->Supply->id = $this->request->data['Supply']['id'];
                if (!$this->Supply->exists()) {
                    $this->Session->setFlash(
                        __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                        Invalid supply id = '.$id.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                    );
                }elseif($p = $this->Supply->find('first', array('conditions'=>array('Supply.id'=>$this->request->data['Supply']['id'],'Supply.Branch'=>'BranchB')))){
                    $this->set('supplyi', $p);
                }else{
                    $this->Session->setFlash(
                        __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                        Supply id = '.$id.' is not for this branch. Please, try again.'), 'default', array('class'=>'alert alert-error')
                    );
                }             
                                                
            }
    }
    
    public function Branchb_returnedsupply(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->ReturnedSupply->create();
            if ($this->ReturnedSupply->save($this->request->data['Supply'])) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Returned Purchase has been Saved. <br />';
                $this->Product->id = $this->request->data['Supply']['Item'];
                $prod = $this->Product->read();
                $prodb = $this->BranchbInventory->find('first',array('conditions'=>array('BranchbInventory.Item'=>$prod['Product']['Item'])));
                $newdata = array();
                $newdata['Product']['Quantity'] = $prod['Product']['Quantity'] + $this->request->data['Supply']['Quantity'];
                $newdata['Item']['Quantity'] = $prodb['BranchbInventory']['Quantity'] - $this->request->data['Supply']['Quantity'];
                $this->BranchbInventory->id = $prodb['BranchbInventory']['id'];
                if($this->Product->save($newdata['Product'])){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated. <br />';
                }else{
                    $msg .= '<b>Error!</b> The Product Quantity could not be updated. <br />';
                }
                if($this->BranchbInventory->save($newdata['Item'])){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated in Inventory. <br />';
                }else{
                    $msg .= '<b>Error!</b> The Product Quantity could not be updated in Inventory. <br />';
                }
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                $this->redirect(array('action'=>'returned'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Purchase could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function Branchb_view_returned() {
        $this->set('supplies', $this->ReturnedSupply->find('all',array('conditions'=>array('ReturnedSupply.Branch'=>'BranchB'))));
    }
    
    public function Branchb_inventory() {
        $this->set('inventories', $this->BranchbInventory->find('all'));
    }
    
}
?>