<?php
// app/controller/PurchasesController

App::uses('AppController','Controller');

class PurchasesController extends AppController {
    public $uses = array('Purchase','Product','ReturnedPurchase','PrePurchase','Customer','Batch');
    public $components = array('RequestHandler');
    public $helpers = array('Js');
	
	public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    return $this->redirect(
                        array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchB'){
                    return $this->redirect(
                        array('BranchB'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }
    }
	
	public function beforeFilter() {
        parent::beforeFilter();
        $router = Router::parse(Router::normalize(Router::url()));
        $user = $this->Auth->user();
        if(!($user['Office']==$router['prefix'])){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                Warning! Invalid Access Area.'), 'default', array('class'=>'alert alert-warning')
            );
            $this->userRedirect();
        }
    }
    
    public function Warehouse_add() {
        $this->set('prodlist', $this->Product->find('list',array('fields'=>array('Product.Item'))));
		$this->set('customers', $this->Customer->find('list',array('fields'=>array('Customer.Name'), 'conditions'=>array('Customer.Type'=>'Supplier'))));
                
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->Purchase->create();
            $this->Product->id = $this->request->data['Purchase']['Item'];
            $data = $this->request->data['Purchase'];
            $prod = $this->Product->read();
            $customer = $this->Customer->read(null,$data['Supplier']);
            $data['Supplier'] = $customer['Customer']['Name'];
            $data['CustomerId'] = $customer['Customer']['id'];
            $data['Item'] = $prod['Product']['Item'];
            $data['ItemId'] = $prod['Product']['id'];
            if ($this->Purchase->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Purchase has been Saved. <br />';
                
                $newdata = array();
                $newdata['Product']['Quantity'] = $prod['Product']['Quantity'] + $this->request->data['Purchase']['Quantity'];
                $newdata['Product']['Price'] = $this->request->data['Purchase']['UnitPrice'];
                if($this->Product->save($newdata)){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated. <br />';
                }else{
                    $msg .= '<b>Error.</b> The Product Quantity could not be updated. <br />';
                }
                $batchData = array();
                $batchData = $data;
                $batchData['id'] = $data['Batch_id'];
                $batchData['Product_id'] = $data['ItemId'];
                if($this->Batch->save($batchData)){
                    $msg .= '<b>Success.</b> The Batch has been saved. <br />';
                }else{
                    $msg .= '<b>Error.</b> The Batch could not be saved. <br />';
                }
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                $this->redirect(array('action'=>'add'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Purchase could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function ajax_batch_list(){        
        $list = $this->Batch->find('list',array('fields'=>array('Batch.BatchNo'), 'conditions'=>array('Batch.ProductId'=>$this->request->data['Purchase']['ItemId']), 'recursive'=>-1));
        $this->set('batchList', $list);
        $this->layout = 'ajax';
    }
    
    public function edit() {
        
    }
    
    public function delete() {
        
    }
    
    public function Warehouse_view() {
        $this->set('purchase', $this->Purchase->find('all'));
    }
    
    public function Warehouse_returned($id=null) {
            if ($this->request->is('post') || $this->request->is('put')) {
                $this->Purchase->id = $this->request->data['Purchase']['id'];
                if (!$this->Purchase->exists()) {
                    $this->Session->setFlash(
                        __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                        Invalid purchase id = '.$id.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                    );
                }
                $p = $this->Purchase->find('first', array('conditions'=>array('Purchase.id'=>$this->request->data['Purchase']['id'])));
                $this->set('purchasei', $p);
                $this->set('item', $this->Product->read(null, $p['Purchase']['Item']));                
            }
    }
    
    public function Warehouse_returnedpurchase(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->ReturnedPurchase->create();
            if ($this->ReturnedPurchase->save($this->request->data['Purchase'])) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Returned Purchase has been Saved. <br />';
                $this->Product->id = $this->request->data['Purchase']['Item'];
                $prod = $this->Product->read();
                $newdata = array();
                $newdata['Product']['Quantity'] = $prod['Product']['Quantity'] - $this->request->data['Purchase']['Quantity'];
                if($this->Product->save($newdata)){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated. <br />';
                }else{
                    $msg .= '<b>Error.</b> The Product Quantity could not be updated. <br />';
                }
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                $this->redirect(array('action'=>'returned'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Purchase could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function Warehouse_view_returned() {
        $this->set('purchase', $this->ReturnedPurchase->find('all'));
    }
	
	public function Warehouse_prepurchase() {
        $this->set('prodlist', $this->Product->find('list',array('fields'=>array('Product.Item'))));
        $this->set('customers', $this->Customer->find('list',array('fields'=>array('Customer.Name'), 'conditions'=>array('Customer.Type'=>'Supplier'))));
                
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->PrePurchase->create();
            $this->Product->id = $this->request->data['PrePurchase']['Item'];
            $data = $this->request->data['PrePurchase'];
            $prod = $this->Product->read();
            $data['Item'] = $prod['Product']['Item'];
            $data['ItemId'] = $prod['Product']['id'];
            $customer = $this->Customer->read(null,$data['Supplier']);
            $data['Supplier'] = $customer['Customer']['Name'];
            $data['CustomerId'] = $customer['Customer']['id'];
            if ($this->PrePurchase->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The PRE Purchase has been Saved. <br />';
                                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                $this->redirect(array('action'=>'add'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Purchase could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
	
	public function Warehouse_view_prepurchase() {
        $this->set('purchase', $this->PrePurchase->find('all'));
    }
	
	public function Warehouse_edit_prepurchase($id=null) {
        $this->set('prodlist', $this->Product->find('list',array('fields'=>array('Product.Item'))));
        
        $this->PrePurchase->id = $id;
        if (!$this->PrePurchase->exists()) {
            throw new NotFoundException(__('Invalid PRE Purchase'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->PrePurchase->save($this->request->data)) {
                $this->Session->setFlash(__('The user has been updated'));
                return $this->redirect(array('action' => 'view_prepurchase'));
            }
            $this->Session->setFlash(
                __('The user could not be saved. Please, try again.')
            );
        } else {
            $this->request->data = $this->PrePurchase->read(null, $id);
        }
    }
    
}
?>