<?php
// app/controller/ProductsController

App::uses('AppController','Controller');

class ExpendituresController extends AppController {
    public $uses = array('BranchaExpenditure', 'BranchbExpenditure');
    
    public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    return $this->redirect(
                        array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchB'){
                    return $this->redirect(
                        array('BranchB'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $router = Router::parse(Router::normalize(Router::url()));
        $user = $this->Auth->user();
        if(!($user['Office']==$router['prefix'])){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                Warning! Invalid Access Area.'), 'default', array('class'=>'alert alert-warning')
            );
            $this->userRedirect();
        }
    }
    
    // **BranchA ...
        
    public function BranchA_add() {
        if ($this->request->is('post') || $this->request->is('put')) { 
            $this->BranchaExpenditure->create();
            $data = $this->request->data;
            if ($this->BranchaExpenditure->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Expenditure has been recorded. <br />';               
                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action'=>'add'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Expenditure could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }        
    }
    
    public function BranchA_edit($id=null) {
        $this->BranchaExpenditure->id = $id;
        
        if (!$this->BranchaExpenditure->exists()) {
            throw new NotFoundException(__('Invalid Roof Product'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->BranchaExpenditure->create();
            $data = $this->request->data;
            if ($this->BranchaExpenditure->save($this->request->data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Expenditure has been saved. <br />';
                                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Expenditure could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->BranchaExpenditure->read(null, $id);
        }
    }
    
    public function BranchA_delete($id=null) {
        
        $this->BranchaExpenditure->id = $id;
        
        if (!$this->BranchaExpenditure->exists()) {
            throw new NotFoundException(__('Invalid Product'));
        }
        if ($this->BranchaExpenditure->delete()) {
            $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
            <b>Success.</b> Expenditure deleted'),'default', array('class'=>'alert alert-success'));
            return $this->redirect(array('action' => 'view'));
        }
        $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
        The Expenditure was not deleted'), 'default', array('class'=>'alert alert-error'));
        return $this->redirect(array('action' => 'view'));
    }
    
    public function BranchA_view() {
        $this->set('expenditures', $this->BranchaExpenditure->find('all'));
    }
    
    // !- BranchA functions --
    
    // **BranchB ...
    
    public function BranchB_add() {
        if ($this->request->is('post') || $this->request->is('put')) { 
            $this->BranchbExpenditure->create();
            $data = $this->request->data;
            if ($this->BranchbExpenditure->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Expenditure has been recorded. <br />';               
                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action'=>'add'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Expenditure could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }        
    }
    
    public function BranchB_edit($id=null) {
        $this->BranchbExpenditure->id = $id;
        
        if (!$this->BranchbExpenditure->exists()) {
            throw new NotFoundException(__('Invalid Expenditure'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->BranchbExpenditure->create();
            $data = $this->request->data;
            if ($this->BranchbExpenditure->save($this->request->data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Expenditure has been saved. <br />';
                                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Expenditure could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->BranchbExpenditure->read(null, $id);
        }
    }
    
    public function BranchB_delete($id=null) {
        
        $this->BranchbExpenditure->id = $id;
        
        if (!$this->BranchbExpenditure->exists()) {
            throw new NotFoundException(__('Invalid Expenditure'));
        }
        if ($this->BranchbExpenditure->delete()) {
            $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
            <b>Success.</b> Expenditure deleted'),'default', array('class'=>'alert alert-success'));
            return $this->redirect(array('action' => 'view'));
        }
        $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
        The Expenditure was not deleted'), 'default', array('class'=>'alert alert-error'));
        return $this->redirect(array('action' => 'view'));
    }
    
    public function BranchB_view() {
        $this->set('expenditures', $this->BranchbExpenditure->find('all'));
    }
    
    // !- BranchB functions --
    
    // Warehouse ...
    
    public function Warehouse_report($Branch) {
        if ($this->request->is('post') || $this->request->is('put')) {
            if($Branch=='BranchA'){
            $data = $this->request->data;
            $from = implode('-',array($data['BranchaExpenditure']['From']['year'],$data['BranchaExpenditure']['From']['month'],$data['BranchaExpenditure']['From']['day']));
            $to = implode('-',array($data['BranchaExpenditure']['To']['year'],$data['BranchaExpenditure']['To']['month'],$data['BranchaExpenditure']['To']['day']));
            
            $reports = $this->BranchaExpenditure->find('all',array('conditions'=>array('BranchaExpenditure.Date BETWEEN ? AND ?'=>array($from,$to))));
            $reportsum = $this->BranchaExpenditure->find('all',array('fields'=>array('sum(BranchaExpenditure.Amount) as SumAmount'),'conditions'=>array('BranchaExpenditure.Date BETWEEN ? AND ?'=>array($from,$to))));
            if(count($reports)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('reports',$reports);
                $this->set('reportsum',$reportsum[0][0]);
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
            }
            }elseif($Branch=='BranchB'){
            $data = $this->request->data;
            $from = implode('-',array($data['BranchaExpenditure']['From']['year'],$data['BranchaExpenditure']['From']['month'],$data['BranchaExpenditure']['From']['day']));
            $to = implode('-',array($data['BranchaExpenditure']['To']['year'],$data['BranchaExpenditure']['To']['month'],$data['BranchaExpenditure']['To']['day']));
            
            $reports = $this->BranchbExpenditure->find('all',array('conditions'=>array('BranchbExpenditure.Date BETWEEN ? AND ?'=>array($from,$to))));
            $reportsum = $this->BranchbExpenditure->find('all',array('fields'=>array('sum(BranchbExpenditure.Amount) as SumAmount'),'conditions'=>array('BranchbExpenditure.Date BETWEEN ? AND ?'=>array($from,$to))));
            if(count($reports)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('reports',$reports);
                $this->set('reportsum',$reportsum[0][0]);
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
            }
            }
        }
    }
    
    // !- Warehouse functions --
      
}
?>