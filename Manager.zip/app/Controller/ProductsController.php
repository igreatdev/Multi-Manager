<?php
// app/controller/ProductsController

App::uses('AppController','Controller');

class ProductsController extends AppController {
    public $uses = array('Product', 'ProductCategory', 'BranchaInventory', 'BranchbInventory','Batch');
    
    public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    return $this->redirect(
                        array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchB'){
                    return $this->redirect(
                        array('BranchB'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $router = Router::parse(Router::normalize(Router::url()));
        $user = $this->Auth->user();
        if(!$this->request->is('ajax')){
            if(!($user['Office']==$router['prefix'])){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                Warning! Invalid Access Area.'), 'default', array('class'=>'alert alert-warning')
                );
                $this->userRedirect();
            }
        }
    }
        
    public function Warehouse_add() {
        $this->set('categories',$this->ProductCategory->find('list',array('fields'=>array('ProductCategory.Category'))));
        if ($this->request->is('post') || $this->request->is('put')) { 
            $this->Product->create();
            $data = $this->request->data;
            
            if ($this->Product->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Product has been created. <br />';
                unset($data['Product']['Price']);
                $id = $this->Product->getLastInsertId();
                $data['Product']['ItemId'] = $id;
                if($this->BranchaInventory->save($data['Product'])){
                    $msg .= '<b>Success.</b> Branch A Products has been updated. <br />';                    
                }else{
                    $msg .= '<b>Error!</b> Branch A Products could not be updated. <br />';
                }
                if($this->BranchbInventory->save($data['Product'])){
                    $msg .= '<b>Success.</b> Branch B Products has been updated. <br />';
                }else{
                    $msg .= '<b>Error!</b> Branch B Products could not be updated. <br />';
                }
                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action'=>'add'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Product could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }        
    }
    
    public function Warehouse_edit($id=null) {
        $this->Product->id = $id;
        
        if (!$this->Product->exists()) {
            throw new NotFoundException(__('Invalid Roof Product'));
        }
        $this->set('categories',$this->ProductCategory->find('list',array('fields'=>array('ProductCategory.Category'))));
        
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data;
            $data['Product']['ItemId'] = $data['Product']['id'];
            
            if ($this->Product->save($this->request->data)) {
                $p = $this->Product->read();
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Product has been saved. <br />';
                unset($data['Product']['Price'],$data['Product']['id']);
                foreach($data['Product'] as $key => $prod){
                    $data['Product'][$key] = "'".$prod."'";
                }
                print_r($data); 
                if($this->BranchaInventory->updateAll($data['Product'],array('BranchaInventory.Item'=>$p['Product']['Item']))){
                    $msg .= '<b>Success.</b> Branch A Products has been updated. <br />';                    
                }else{
                    $msg .= '<b>Error!</b> Branch A Products could not be updated. <br />';
                }
                if($this->BranchbInventory->updateAll($data['Product'],array('BranchbInventory.Item'=>$p['Product']['Item']))){
                    $msg .= '<b>Success.</b> Branch B Products has been updated. <br />';
                }else{
                    $msg .= '<b>Error!</b> Branch B Products could not be updated. <br />';
                }
                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Product could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->Product->read(null, $id);
        }
    }
    
    public function Warehouse_delete($id=null) {
        
        $this->Product->id = $id;
        
        if (!$this->Product->exists()) {
            throw new NotFoundException(__('Invalid Product'));
        }
        
        if ($this->Product->delete()) {
            $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Product has been deleted. <br />';
                $BA = $this->BranchaInventory->find('first',array('fields'=>array('BranchaInventory.id'),'conditions'=>array('BranchaInventory.ItemId'=>$id)));
                $BB = $this->BranchbInventory->find('first',array('fields'=>array('BranchbInventory.id'),'conditions'=>array('BranchbInventory.ItemId'=>$id)));
                if($this->BranchaInventory->delete($BA['BranchaInventory']['id'])){
                    $msg .= '<b>Success.</b> Branch A Product has been deleted. <br />';                    
                }else{
                    $msg .= '<b>Error!</b> Branch A Product could not be deleted. <br />';
                }
                if($this->BranchbInventory->delete($BB['BranchbInventory']['id'])){
                    $msg .= '<b>Success.</b> Branch B Product has been deleted. <br />';
                }else{
                    $msg .= '<b>Error!</b> Branch B Products could not be deleted. <br />';
                }
                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
        }
        $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
        Product was not deleted'), 'default', array('class'=>'alert alert-error'));
        return $this->redirect(array('action' => 'view'));
    }
    
    public function Warehouse_view() {
        $this->set('products', $this->Product->find('all'));
    }
    
    public function Warehouse_product($id=null) {
        $this->Product->id = $id;
        
        if (!$this->Product->exists()) {
            throw new NotFoundException(__('Invalid Product'));
        }
        
        $this->set('products', $this->Product->read());
    }
    
    public function Warehouse_category() {
        $this->set('category', $this->ProductCategory->find('all'));
        
        if ($this->request->is('post') || $this->request->is('put')) { 
            $this->ProductCategory->create();
            $data = $this->request->data;
            
            if ($this->ProductCategory->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Product has been added. <br />';
                                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action'=>'category'));                                                                                      
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Product could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function ajax_product_list(){        
        $list = $this->Product->find('list',array('fields'=>array('Product.Item'), 'conditions'=>array('Product.Category_id'=>$this->request->data['Category']), 'recursive'=>-1));
        $this->set('productList', $list);
        $this->layout = 'ajax';
    }
    
    public function ajax_batch_list(){        
        $list = $this->Batch->find('list',array('fields'=>array('Batch.id'), 'conditions'=>array('Batch.Product_id'=>$this->request->data['Product']), 'recursive'=>-1));
        $this->set('batchList', $list);
        $this->layout = 'ajax';
    }
    
    // !- Warehouse functions --
       
}
?>