<?php
// app/controller/SalesController

App::uses('AppController','Controller');

class SalesController extends AppController {
    public $uses = array('BranchaSaleSummary', 'BranchaInventory', 
                            'BranchaSaleItem', 'BranchaSalePayment', 
                            'BranchaReturnedSaleitem', 'BranchaExpenditure', 
                            'BranchbSaleSummary', 'BranchbInventory', 
                            'BranchbSaleItem', 'BranchbSalePayment', 
                            'BranchbReturnedSaleitem', 'BranchbExpenditure',
                            'Customer','ProductCategory','Batch','Product');
                            
    public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    if($user['role']==='B Manager'){
                        return $this->redirect(
                            array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                        );
                    }else if($user['role']==='POS'){
                        return $this->redirect(
                            array('BranchA'=>true, 'controller'=>'sales', 'action'=>'add')
                        );
                    }
                }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $router = Router::parse(Router::normalize(Router::url()));
        $user = $this->Auth->user();
        if(!$this->request->is('Ajax')){
         if(!($user['Office']==$router['prefix'])){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                Warning! Invalid Access Area.'), 'default', array('class'=>'alert alert-warning')
            );
            $this->userRedirect();
        }   
        }        
    }
    
    // **BranchA ...
    
    public function Brancha_add() {
        $this->set('category', $this->ProductCategory->find('list',array('fields'=>array('ProductCategory.Category'))));
        
        if($this->BranchaSaleSummary->find('count')>0){
            $invoice = $this->BranchaSaleSummary->find('first',array('fields'=>array('BranchaSaleSummary.InvoiceNo'), 'order'=>array('InvoiceNo'=>'DESC')));
            $num = $invoice['BranchaSaleSummary']['InvoiceNo'] + 1;
            $invNo = sprintf('%05d',$num);
        }else{
            $invNo = '00001';
        }
        $this->set('invoiceNo', $invNo);
        
        
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->BranchaSaleSummary->validates()) {
                $this->BranchaSaleSummary->create();
                $data = $this->request->data['BranchaSaleSummary'];
                $dataItem = $this->request->data['Item'];
                $items = array();
                
                if($this->BranchaSaleSummary->save($data)){
                    $id = $this->BranchaSaleSummary->getLastInsertId();
                    $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                                <b>Success.</b> The Sales has been created.<br /> <a href="sale_receipt/'.
                                $id.'">Print Reciept</a> <br />';
                    foreach($dataItem as $item){
                        $it = $this->BranchaInventory->find('first',array('conditions'=>array('BranchaInventory.Batch_id'=>$item['Batch_id'])));
                        if($item['Quantity'] > $it['BranchaInventory']['Quantity']){
                            $msg .= '<strong>'.$item['Item'].'</strong>: Quantity requested is greater quantity available in Batch!';
                            $data['TotalAmount'] = $data['TotalAmount'] - $item['Amount'];
                        }else{
                            $nwdata = array();
                            $nwdata['Quantity'] = $it['BranchaInventory']['Quantity'] - $item['Quantity'];
                            $nwdata['LastSale'] = $data['Date'];
                            $this->BranchaInventory->id = $it['BranchaInventory']['id'];
                            
                            $item['InvoiceNo'] = $data['InvoiceNo'];
                            $item['Date'] = $data['Date'];
                            $item['User'] = $data['User'];
                            
                            $this->BranchaSaleItem->create();
                            if($this->BranchaSaleItem->save($item)){
                                if($this->BranchaInventory->save($nwdata)){
                                    
                                }                                
                            }
                        
                        }
                    }
                    $this->BranchaSaleSummary->id = $id;
                    if($this->BranchaSaleSummary->save($data)){}
                                        
                    $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                    return $this->redirect(array('action' => 'sale_receipt',$this->BranchaSaleSummary->getLastInsertID()));
                }
                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Sales could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function ajax_batch_list(){        
        $list = $this->BranchaInventory->find('list',array('fields'=>array('BranchaInventory.Batch_id','BranchaInventory.Batch_id'), 'conditions'=>array(
        'BranchaInventory.Product_id'=>$this->request->data['Product'], 'BranchaInventory.Quantity >'=>0), 'recursive'=>-1));
        $this->set('batchList', $list);
        $this->layout = 'ajax';
    }
    
    public function ajax_batch(){        
        $list = $this->BranchaInventory->find('first',array('fields'=>array('BranchaInventory.Quantity','BranchaInventory.Price'), 'conditions'=>array(
        'BranchaInventory.Batch_id'=>$this->request->data['Batch'], 'BranchaInventory.Quantity >'=>0), 'recursive'=>-1));
        $this->set('batchList', $list);
        $this->layout = 'ajax';
    }
    
    public function Brancha_sale_receipt($id=null){
        $this->BranchaSaleSummary->id = $id;
        $summary = $this->BranchaSaleSummary->read();
        $itemlist = $this->BranchaSaleItem->find('all', array('conditions'=>array('BranchaSaleItem.InvoiceNo'=>$summary['BranchaSaleSummary']['InvoiceNo'])));        
        $this->set('summary',$summary);
        $this->set('items', $itemlist);
                
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data['BranchaSaleSummary'];
            $voucherupd = array();
            if($data['Method'] == 'Voucher'){
                $this->Voucher->id = $data['Voucher'];
                if(!$this->Voucher->exists()){
                    $this->Session->setFlash(__('Invalid Voucher!'),'default', array('class'=>'alert alert-error'));
                    return $this->redirect(array($id));
                }else{
                    $voucher = $this->Voucher->read();
                    if($data['AmountPaid'] > $voucher['Voucher']['Balance'] ){
                        $this->Session->setFlash(__('Amount entered is greater than voucher balance!'),'default', array('class'=>'alert alert-error'));
                        return $this->redirect(array($id));
                    }else{
                        $voucherupd['Balance'] = $voucher['Voucher']['Balance'] - $data['AmountPaid'];
                        $voucherupd['Used'] = $voucher['Voucher']['Used'] + $data['AmountPaid'];
                        $voucherupd['LastUse'] = $data['Date']; 
                        if($this->Voucher->save($voucherupd)){
                            $data['Token']='Voucher['.$voucher['Voucher']['VoucherNo'].']';
                        }
                    }
                }
            }
            $data['Balance'] = $data['AmountOwing'] - $data['AmountPaid'];
            
            $sum = array();
            $sum['AmountPaid'] = $summary['BranchaSaleSummary']['AmountPaid'] + $data['AmountPaid'];
            $sum['Balance'] = $data['Balance'];
            if($data['Balance'] > 0){
                $sum['Status'] = 'Debit';
            }else{
                $sum['Status'] = 'Paid';
            }
            
            if($this->BranchaSalePayment->save($data)){                
                if($this->BranchaSaleSummary->save($sum)){
                    $this->Session->setFlash(__('Payment made successfully!'),'default', array('class'=>'alert alert-success'));
                    return $this->redirect(array($id));
                }
            }
        }
    }
    
    public function Brancha_print_receipt($id=null){
        $this->layout = 'invoice';
        $this->BranchaSaleSummary->id = $id;
        $summary = $this->BranchaSaleSummary->read();
        $itemlist = $this->BranchaSaleItem->find('all', array('conditions'=>array('BranchaSaleItem.InvoiceNo'=>$summary['BranchaSaleSummary']['InvoiceNo'])));        
        $this->set('summary',$summary);
        $this->set('items', $itemlist);
    }
    
    public function Brancha_pay_balance(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data['BranchaSaleSummary'];
            $sale = $this->BranchaSaleSummary->find('first',array('conditions'=>array('BranchaSaleSummary.InvoiceNo'=>$data['InvoiceNo'])));
            
            if(count($sale)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! for Invoice '.$data['InvoiceNo'].'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                return $this->redirect(array('action'=>'sale_receipt',$sale['BranchaSaleSummary']['id']));
            }
        }
    }
    
    public function Brancha_returned(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data['BranchaSaleSummary'];
            $sale = $this->BranchaSaleSummary->find('first',array('conditions'=>array('BranchaSaleSummary.InvoiceNo'=>$data['InvoiceNo'])));
            
            if(count($sale)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! for Invoice '.$data['InvoiceNo'].'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $saleItems = $this->BranchaSaleItem->find('all',array('conditions'=>array('BranchaSaleItem.InvoiceNo'=>$data['InvoiceNo'])));
                $saleItemlist = $this->BranchaSaleItem->find('list',array('conditions'=>array('BranchaSaleItem.InvoiceNo'=>$data['InvoiceNo']),
                                                                'fields'=>array('BranchaSaleItem.Item')));
                $this->set('saleItemlist',$saleItemlist);
                $this->set('saleItems',$saleItems);
                $this->set('sale',$sale);
                
            }
        }
    }
    
    public function Brancha_returnedsale(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->BranchaReturnedSaleitem->create();
            $data = $this->request->data;
            $sale = $this->BranchaSaleItem->find('first',array('conditions'=>array('BranchaSaleItem.id'=>$data['Item'])));
            $data['Item'] = $sale['BranchaSaleItem']['Item'];
            if($data['Quantity']>$sale['BranchaSaleItem']['Quantity']){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Quantity returned is greater than quantity sold. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
            $this->redirect(array('action'=>'returned'));    
            }else{
            if ($this->BranchaReturnedSaleitem->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Returned Sale has been Saved. <br />';
                $prod = $this->BranchaInventory->find('first',array('conditions'=>array('BranchaInventory.Item'=>$data['Item'])));
                $newdata = array();
                $newdata['Quantity'] = $prod['BranchaInventory']['Quantity'] + $data['Quantity'];
                $this->BranchaInventory->id = $prod['BranchaInventory']['id'];
                if($this->BranchaInventory->save($newdata)){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated. <br />';
                }else{
                    $msg .= '<b>Error.</b> The Product Quantity could not be updated. <br />';
                }
                                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                $this->redirect(array('action'=>'returned'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Returned Sale could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
            $this->redirect(array('action'=>'returned'));    
            }
                        
        }
    }
    
    public function Brancha_view_returned(){
        $this->set('sale',$this->BranchaReturnedSaleitem->find('all'));
    }
    
    public function Brancha_view($user=null) {
        if($user == null){
            $this->set('sale', $this->BranchaSaleSummary->find('all'));
        }else{
            $this->set('sale', $this->BranchaSaleSummary->find('all',array('conditions'=>array('BranchaSaleSummary.User'=>$user), 'Order'=>'BranchaSaleSummary.Date DESC')));
        }
    }
    
    // ! BranchA functions --
    
    // **BranchB ...
    
    public function Branchb_add() {
        $this->set('prodlist', $this->BranchbInventory->find('list',array('fields'=>array('BranchbInventory.ItemId', 'BranchbInventory.Item'), 'conditions'=>array('BranchbInventory.Quantity >'=>0))));
        $this->set('customers', $this->Customer->find('list',array('fields'=>array('Customer.Name'), 'conditions'=>array('Customer.Type'=>'Buyer'))));
        
        if($this->BranchbSaleSummary->find('count')>0){
            $invoice = $this->BranchbSaleSummary->find('first',array('fields'=>array('BranchbSaleSummary.InvoiceNo'), 'order'=>array('InvoiceNo'=>'DESC')));
            $num = $invoice['BranchbSaleSummary']['InvoiceNo'] + 1;
            $invNo = sprintf('%05d',$num);
        }else{
            $invNo = '00001';
        }
        $this->set('invoiceNo', $invNo);
        
        
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->BranchbSaleSummary->validates()) {
                $this->BranchbSaleSummary->create();
                $data = $this->request->data['BranchbSaleSummary'];
                $dataItem = $this->request->data['Item'];
                $data['Balance'] = $data['TotalAmount'];
                $items = array();
                if(isset($data['CustomerId'])){
                    $this->Customer->id = $data['CustomerId'];
                    $customer = $this->Customer->read();
                    $data['Buyer'] = $customer['Customer']['Name'];
                    $data['PhoneNo'] = $customer['Customer']['PhoneNo'];
                }
                if($this->BranchbSaleSummary->save($data)){
                    $id = $this->BranchbSaleSummary->getLastInsertId();
                    $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                                <b>Success.</b> The Sales has been created.<br /> <a href="sale_receipt/'.
                                $id.'">Print Reciept</a> <br />';
                    foreach($dataItem as $item){
                        $it = $this->BranchbInventory->find('first',array('conditions'=>array('BranchbInventory.ItemId'=>$item['ItemId'])));
                        if($item['Quantity'] > $it['BranchbInventory']['Quantity']){
                            $msg .= '<strong>'.$item['Item'].'</strong>: Quantity requested is greater quantity available!';
                            $data['TotalAmount'] = $data['TotalAmount'] - $item['Amount'];
                            $data['Balance'] = $data['Balance'] - $item['Amount'];
                        }else{
                            $nwdata = array();
                            $nwdata['Quantity'] = $it['BranchbInventory']['Quantity'] - $item['Quantity'];
                            $nwdata['LastSale'] = $data['Date'];
                            $this->BranchbInventory->id = $it['BranchbInventory']['id'];
                            
                            $prof = $item['Price'] - $it['BranchbInventory']['Price'];
                            
                            $item['SaleProfit'] = $prof * $item['Quantity'];
                            $item['InvoiceNo'] = $data['InvoiceNo'];
                            $item['Date'] = $data['Date'];
                            $item['User'] = $data['User'];
                            
                            $this->BranchbSaleItem->create();
                            if($this->BranchbSaleItem->save($item)){
                                if($this->BranchbInventory->save($nwdata)){
                                    
                                }                                
                            }
                        
                        }
                    }
                    $this->BranchbSaleSummary->id = $id;
                    if($this->BranchbSaleSummary->save($data)){}
                                        
                    $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                    return $this->redirect(array('action' => 'add'));
                }
                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Sales could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function Branchb_sale_receipt($id=null){
        $this->BranchbSaleSummary->id = $id;
        $summary = $this->BranchbSaleSummary->read();
        $itemlist = $this->BranchbSaleItem->find('all', array('conditions'=>array('BranchbSaleItem.InvoiceNo'=>$summary['BranchbSaleSummary']['InvoiceNo'])));        
        $this->set('summary',$summary);
        $this->set('items', $itemlist);
        $method = array('Cash'=>'Cash','Bank'=>'Bank');
        $this->Customer->id = $summary['BranchbSaleSummary']['CustomerId'];
        
        if($this->Customer->exists()){
            $vouchers = $this->Voucher->find('list',array('fields'=>array('Voucher.VoucherNo'),'conditions'=>array(
                        'Voucher.CustomerId'=>$summary['BranchbSaleSummary']['CustomerId'], 'Voucher.Balance >'=>0)));
            if(count($vouchers) > 0){
                $method['Voucher']='Voucher';
                $this->set('vouchers',$vouchers);
            }
        }
        $this->set('method',$method);
        
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data['BranchbSaleSummary'];
            $voucherupd = array();
            if($data['Method'] == 'Voucher'){
                $this->Voucher->id = $data['Voucher'];
                if(!$this->Voucher->exists()){
                    $this->Session->setFlash(__('Invalid Voucher!'),'default', array('class'=>'alert alert-error'));
                    return $this->redirect(array($id));
                }else{
                    $voucher = $this->Voucher->read();
                    if($data['AmountPaid'] > $voucher['Voucher']['Balance'] ){
                        $this->Session->setFlash(__('Amount entered is greater than voucher balance!'),'default', array('class'=>'alert alert-error'));
                        return $this->redirect(array($id));
                    }else{
                        $voucherupd['Balance'] = $voucher['Voucher']['Balance'] - $data['AmountPaid'];
                        $voucherupd['Used'] = $voucher['Voucher']['Used'] + $data['AmountPaid'];
                        $voucherupd['LastUse'] = $data['Date']; 
                        if($this->Voucher->save($voucherupd)){
                            $data['Token']='Voucher['.$voucher['Voucher']['VoucherNo'].']';
                        }
                    }
                }
            }
            $data['Balance'] = $data['AmountOwing'] - $data['AmountPaid'];
            
            $sum = array();
            $sum['AmountPaid'] = $summary['BranchbSaleSummary']['AmountPaid'] + $data['AmountPaid'];
            $sum['Balance'] = $data['Balance'];
            if($data['Balance'] > 0){
                $sum['Status'] = 'Debit';
            }else{
                $sum['Status'] = 'Paid';
            }
            
            if($this->BranchbSalePayment->save($data)){                
                if($this->BranchbSaleSummary->save($sum)){
                    $this->Session->setFlash(__('Payment made successfully!'),'default', array('class'=>'alert alert-success'));
                    return $this->redirect(array($id));
                }
            }
        }
    }
    
    public function Branchb_print_receipt($id=null){
        $this->layout = 'invoice';
        $this->BranchbSaleSummary->id = $id;
        $summary = $this->BranchbSaleSummary->read();
        $itemlist = $this->BranchbSaleItem->find('all', array('conditions'=>array('BranchbSaleItem.InvoiceNo'=>$summary['BranchbSaleSummary']['InvoiceNo'])));        
        $this->set('summary',$summary);
        $this->set('items', $itemlist);
        
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data['BranchbSaleSummary'];
            $data['Balance'] = $data['AmountOwing'] - $data['AmountPaid'];
            
            $sum = array();
            $sum['AmountPaid'] = $summary['BranchbSaleSummary']['AmountPaid'] + $data['AmountPaid'];
            $sum['Balance'] = $data['Balance'];
            
            if($this->BranchbSalePayment->save($data)){
                if($this->BranchbSaleSummary->save($sum)){
                    $this->Session->setFlash(__('Payment made successfully!'),'default', array('class'=>'alert alert-success'));
                    return $this->redirect(array($id));
                }
            }
        }
    }
    
    public function Branchb_pay_balance(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data['BranchbSaleSummary'];
            $sale = $this->BranchbSaleSummary->find('first',array('conditions'=>array('BranchbSaleSummary.InvoiceNo'=>$data['InvoiceNo'])));
            
            if(count($sale)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! for Invoice '.$data['InvoiceNo'].'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                return $this->redirect(array('action'=>'sale_receipt',$sale['BranchbSaleSummary']['id']));
            }
        }
    }
    
    public function Branchb_returned(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $data = $this->request->data['BranchbSaleSummary'];
            $sale = $this->BranchbSaleSummary->find('first',array('conditions'=>array('BranchbSaleSummary.InvoiceNo'=>$data['InvoiceNo'])));
            
            if(count($sale)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! for Invoice '.$data['InvoiceNo'].'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $saleItems = $this->BranchbSaleItem->find('all',array('conditions'=>array('BranchbSaleItem.InvoiceNo'=>$data['InvoiceNo'])));
                $saleItemlist = $this->BranchbSaleItem->find('list',array('conditions'=>array('BranchbSaleItem.InvoiceNo'=>$data['InvoiceNo']),
                                                                'fields'=>array('BranchbSaleItem.Item')));
                $this->set('saleItemlist',$saleItemlist);
                $this->set('saleItems',$saleItems);
                $this->set('sale',$sale);
                
            }
        }
    }
    
    public function Branchb_returnedsale(){
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->BranchbReturnedSaleitem->create();
            $data = $this->request->data;
            $sale = $this->BranchbSaleItem->find('first',array('conditions'=>array('BranchbSaleItem.id'=>$data['Item'])));
            $data['Item'] = $sale['BranchbSaleItem']['Item'];
            if($data['Quantity']>$sale['BranchbSaleItem']['Quantity']){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Quantity returned is greater than quantity sold. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
            $this->redirect(array('action'=>'returned'));    
            }else{
            if ($this->BranchbReturnedSaleitem->save($data)) {
                $msg = '<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Returned Sale has been Saved. <br />';
                $prod = $this->BranchbInventory->find('first',array('conditions'=>array('BranchbInventory.Item'=>$data['Item'])));
                $newdata = array();
                $newdata['Quantity'] = $prod['BranchbInventory']['Quantity'] + $data['Quantity'];
                $this->BranchbInventory->id = $prod['BranchbInventory']['id'];
                if($this->BranchbInventory->save($newdata)){
                    $msg .= '<b>Success.</b> The Product Quantity has been updated. <br />';
                }else{
                    $msg .= '<b>Error.</b> The Product Quantity could not be updated. <br />';
                }
                                
                $this->Session->setFlash(__($msg),'default', array('class'=>'alert alert-success'));
                $this->redirect(array('action'=>'returned'));                                                                                          
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Returned Sale could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
            $this->redirect(array('action'=>'returned'));    
            }
                        
        }
    }
    
    public function Branchb_view_returned(){
        $this->set('sale',$this->BranchbReturnedSaleitem->find('all'));
    }
    
    public function Branchb_view() {
        $this->set('sale', $this->BranchbSaleSummary->find('all'));
    }
    
    // ! BranchB functions --
    
    // Warehouse
    
    public function Warehouse_report($Branch=null) {
        if ($this->request->is('post') || $this->request->is('put')) {
        if ($Branch == 'BranchA'){
            $data = $this->request->data;
            $from = implode('-',array($data['BranchaSaleSummary']['From']['year'],$data['BranchaSaleSummary']['From']['month'],$data['BranchaSaleSummary']['From']['day']));
            $to = implode('-',array($data['BranchaSaleSummary']['To']['year'],$data['BranchaSaleSummary']['To']['month'],$data['BranchaSaleSummary']['To']['day']));
            
            $reports = $this->BranchaSaleSummary->find('all',array('conditions'=>array('BranchaSaleSummary.Date BETWEEN ? AND ?'=>array($from,$to))));
            $reportsum = $this->BranchaSaleSummary->find('all',array('fields'=>array('sum(BranchaSaleSummary.TotalAmount) as SumTotal'),'conditions'=>array('BranchaSaleSummary.Date BETWEEN ? AND ?'=>array($from,$to))));
            if(count($reports)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('reports',$reports);
                $this->set('reportsum',$reportsum[0][0]);
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
            }
            
        }elseif($Branch=='BranchB'){
            $data = $this->request->data;
            $from = implode('-',array($data['BranchaSaleSummary']['From']['year'],$data['BranchaSaleSummary']['From']['month'],$data['BranchaSaleSummary']['From']['day']));
            $to = implode('-',array($data['BranchaSaleSummary']['To']['year'],$data['BranchaSaleSummary']['To']['month'],$data['BranchaSaleSummary']['To']['day']));
            
            $reports = $this->BranchbSaleSummary->find('all',array('conditions'=>array('BranchbSaleSummary.Date BETWEEN ? AND ?'=>array($from,$to))));
            $reportsum = $this->BranchbSaleSummary->find('all',array('fields'=>array('sum(BranchbSaleSummary.TotalAmount) as SumTotal'),'conditions'=>array('BranchbSaleSummary.Date BETWEEN ? AND ?'=>array($from,$to))));
            if(count($reports)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('reports',$reports);
                $this->set('reportsum',$reportsum[0][0]);
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
            }
        }
    }
    }
    
    public function Warehouse_financial_report($Branch=null) {
        if ($this->request->is('post') || $this->request->is('put')) { 
            if ($Branch == 'BranchA'){
            $data = $this->request->data;
            $from = implode('-',array($data['BranchaSaleSummary']['From']['year'],$data['BranchaSaleSummary']['From']['month'],$data['BranchaSaleSummary']['From']['day']));
            $to = implode('-',array($data['BranchaSaleSummary']['To']['year'],$data['BranchaSaleSummary']['To']['month'],$data['BranchaSaleSummary']['To']['day']));
            
            $sale = $this->BranchaSaleSummary->find('all',array('fields'=>array('sum(BranchaSaleSummary.TotalAmount) as SumTotal'),'conditions'=>array('BranchaSaleSummary.Date BETWEEN ? AND ?'=>array($from,$to))));
            $saleitem = $this->BranchaSaleItem->find('all',array('fields'=>array('sum(BranchaSaleItem.Amount) as SumAmount','sum(BranchaSaleItem.SaleProfit) as SumProfit'),'conditions'=>array('BranchaSaleItem.Date BETWEEN ? AND ?'=>array($from,$to))));
            //$salepayment = $this->BranchaSalePayment->find('all',array('fields'=>array('sum(BranchaSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchaSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            //$salepaymentcash = $this->BranchaSalePayment->find('all',array('fields'=>array('sum(BranchaSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchaSalePayment.Method'=>'Cash','BranchaSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            //$salepaymentbank = $this->BranchaSalePayment->find('all',array('fields'=>array('sum(BranchaSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchaSalePayment.Method'=>'Bank','BranchaSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            //$salepaymentvoucher = $this->BranchaSalePayment->find('all',array('fields'=>array('sum(BranchaSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchaSalePayment.Method'=>'Voucher','BranchaSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            $expense = $this->BranchaExpenditure->find('all',array('fields'=>array('sum(BranchaExpenditure.Amount) as SumAmount'),'conditions'=>array('BranchaExpenditure.Date BETWEEN ? AND ?'=>array($from,$to))));
            if(count($sale)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('sale',$sale[0][0]);
            }
            if(count($saleitem)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('saleitem',$saleitem[0][0]);
            }
            //if(count($salepayment)<1){
//                $this->Session->setFlash(
//                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
//                No data found! for Payments from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
//                );
//            }else{
//                $this->set('salepayment',$salepayment[0][0]);
//                $this->set('salepaymentcash',$salepaymentcash[0][0]);
//                $this->set('salepaymentbank',$salepaymentbank[0][0]);
//                $this->set('salepaymentvoucher',$salepaymentvoucher[0][0]);
//            }
            if(count($expense)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! for Expenses from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('expense',$expense[0][0]);
            }
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
            
        }elseif($Branch=='BranchB'){
            $data = $this->request->data;
            $from = implode('-',array($data['BranchaSaleSummary']['From']['year'],$data['BranchaSaleSummary']['From']['month'],$data['BranchaSaleSummary']['From']['day']));
            $to = implode('-',array($data['BranchaSaleSummary']['To']['year'],$data['BranchaSaleSummary']['To']['month'],$data['BranchaSaleSummary']['To']['day']));
            
            $sale = $this->BranchbSaleSummary->find('all',array('fields'=>array('sum(BranchbSaleSummary.TotalAmount) as SumTotal','sum(BranchbSaleSummary.AmountPaid) as SumPaid','sum(BranchbSaleSummary.Balance) as SumBalance'),'conditions'=>array('BranchbSaleSummary.Date BETWEEN ? AND ?'=>array($from,$to))));
            $saleitem = $this->BranchbSaleItem->find('all',array('fields'=>array('sum(BranchbSaleItem.Amount) as SumAmount','sum(BranchbSaleItem.SaleProfit) as SumProfit'),'conditions'=>array('BranchbSaleItem.Date BETWEEN ? AND ?'=>array($from,$to))));
            $salepayment = $this->BranchbSalePayment->find('all',array('fields'=>array('sum(BranchbSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchbSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            $salepaymentcash = $this->BranchbSalePayment->find('all',array('fields'=>array('sum(BranchbSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchbSalePayment.Method'=>'Cash','BranchbSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            $salepaymentbank = $this->BranchbSalePayment->find('all',array('fields'=>array('sum(BranchbSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchbSalePayment.Method'=>'Bank','BranchbSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            $salepaymentvoucher = $this->BranchbSalePayment->find('all',array('fields'=>array('sum(BranchbSalePayment.AmountPaid) as SumAmount'),'conditions'=>array('BranchbSalePayment.Method'=>'Voucher','BranchbSalePayment.Date BETWEEN ? AND ?'=>array($from,$to))));
            $expense = $this->BranchbExpenditure->find('all',array('fields'=>array('sum(BranchbExpenditure.Amount) as SumAmount'),'conditions'=>array('BranchbExpenditure.Date BETWEEN ? AND ?'=>array($from,$to))));
            if(count($sale)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('sale',$sale[0][0]);
            }
            if(count($saleitem)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('saleitem',$saleitem[0][0]);
            }
            if(count($salepayment)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('salepayment',$salepayment[0][0]);
                $this->set('salepaymentcash',$salepaymentcash[0][0]);
                $this->set('salepaymentbank',$salepaymentbank[0][0]);
                $this->set('salepaymentvoucher',$salepaymentvoucher[0][0]);
            }
            if(count($expense)<1){
                $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                No data found! from '.$from.' To '.$to.'. Please, try again.'), 'default', array('class'=>'alert alert-error')
                );
            }else{
                $this->set('expense',$expense[0][0]);
            }
                $this->set('from',$from);
                $this->set('to',$to);
                $this->set('Branch',$Branch);
        }
    }
    }
    
    
}
?>