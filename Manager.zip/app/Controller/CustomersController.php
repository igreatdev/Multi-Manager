<?php
// app/controller/CustomersController

App::uses('AppController','Controller');

class CustomersController extends AppController {
    public $uses = array('Customer','BranchaSaleSummary','BranchbSaleSummary','Voucher','Purchase','PrePurchase');
    
    public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    return $this->redirect(
                        array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchB'){
                    return $this->redirect(
                        array('BranchB'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $router = Router::parse(Router::normalize(Router::url()));
        $user = $this->Auth->user();
        if(!($user['Office']==$router['prefix'])){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                Warning! Invalid Access Area.'), 'default', array('class'=>'alert alert-warning')
            );
            $this->userRedirect();
        }
    }
    
    // **BranchA ...
    
    public function BranchA_add() {
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Customer->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The customer has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'customer', $this->Customer->getLastInsertId()));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Customer could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function BranchA_edit($id=null) {
        $this->Customer->id = $id;
        if (!$this->Customer->exists()) {
            throw new NotFoundException(__('Invalid Customer'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Customer->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The customer has been Edited.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Customer could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->Customer->read(null, $id);
        }
    }
    
    public function BranchA_view() {
        $this->set('customers', $this->Customer->find('all',array('conditions'=>array('Customer.Type'=>'Buyer'))));
    }
    
    public function BranchA_customer($id=null) {
        $this->Customer->id = $id;
        if (!$this->Customer->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        $this->set('customerp', $this->Customer->read(null, $id));
        $this->set('sales', $this->BranchaSaleSummary->find('all',array('conditions'=>array('BranchaSaleSummary.CustomerId'=>$id))));
        $this->set('salesBalance', $this->BranchaSaleSummary->find('all',array('fields'=>array('sum(BranchaSaleSummary.Balance)as TotalBalance'),'conditions'=>array('BranchaSaleSummary.CustomerId'=>$id))));
        $this->set('vouchers', $this->Voucher->find('all',array('conditions'=>array('Voucher.CustomerId'=>$id))));
        $this->set('voucherBalance', $this->Voucher->find('all',array('fields'=>array('sum(Voucher.Balance)as TotalBalance'),'conditions'=>array('Voucher.CustomerId'=>$id))));
    }
    
    public function BranchA_addVoucher() {
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->Voucher->create();
            $data = $this->request->data;
            if($this->Voucher->find('count')>0){
                $voucher = $this->Voucher->find('first',array('fields'=>array('Voucher.VoucherNo'), 'order'=>array('id'=>'DESC')));
                $num = $voucher['Voucher']['id'] + 1;
                
            }else{
                $num = '1';
            }
            $data['VoucherNo'] = $data['CustomerId'] . '-' . $num;
            $data['Balance'] = $data['Amount'];
            if ($this->Voucher->save($data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The voucher has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'customer', $data['CustomerId']));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Voucher could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
            return $this->redirect(array('action' => 'customer', $data['CustomerId']));
        }
    }
    
    // **BranchB ...
    
    public function BranchB_add() {
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Customer->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The customer has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'customer', $this->Customer->getLastInsertId()));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Customer could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function BranchB_edit($id=null) {
        $this->Customer->id = $id;
        if (!$this->Customer->exists()) {
            throw new NotFoundException(__('Invalid Customer'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Customer->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The customer has been Edited.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Customer could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->Customer->read(null, $id);
        }
    }
    
    public function BranchB_view() {
        $this->set('customers', $this->Customer->find('all',array('conditions'=>array('Customer.Type'=>'Buyer'))));
    }
    
    public function BranchB_customer($id=null) {
        $this->Customer->id = $id;
        if (!$this->Customer->exists()) {
            throw new NotFoundException(__('Invalid user'));
        }
        $this->set('customerp', $this->Customer->read(null, $id));
        $this->set('sales', $this->BranchbSaleSummary->find('all',array('conditions'=>array('BranchbSaleSummary.CustomerId'=>$id))));
        $this->set('salesBalance', $this->BranchbSaleSummary->find('all',array('fields'=>array('sum(BranchbSaleSummary.Balance)as TotalBalance'),'conditions'=>array('BranchbSaleSummary.CustomerId'=>$id))));
        $this->set('vouchers', $this->Voucher->find('all',array('conditions'=>array('Voucher.CustomerId'=>$id))));
        $this->set('voucherBalance', $this->Voucher->find('all',array('fields'=>array('sum(Voucher.Balance)as TotalBalance'),'conditions'=>array('Voucher.CustomerId'=>$id))));
    }
    
    public function BranchB_addVoucher() {
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->Voucher->create();
            $data = $this->request->data;
            if($this->Voucher->find('count')>0){
                $voucher = $this->Voucher->find('first',array('fields'=>array('Voucher.VoucherNo'), 'order'=>array('id'=>'DESC')));
                $num = $voucher['Voucher']['id'] + 1;
                
            }else{
                $num = '1';
            }
            $data['VoucherNo'] = $data['CustomerId'] . '-' . $num;
            $data['Balance'] = $data['Amount'];
            if ($this->Voucher->save($data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The voucher has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'customer', $data['CustomerId']));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Voucher could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
            return $this->redirect(array('action' => 'customer', $data['CustomerId']));
        }
    }
    
    // Wharehouse ...
    
    public function Warehouse_add() {
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Customer->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The customer has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'customer', $this->Customer->getLastInsertId()));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Customer could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function Warehouse_edit($id=null) {
        $this->Customer->id = $id;
        if (!$this->Customer->exists()) {
            throw new NotFoundException(__('Invalid Customer'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Customer->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The customer has been Edited.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Customer could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->Customer->read(null, $id);
        }
    }
    
    public function Warehouse_view() {
        $this->set('customers', $this->Customer->find('all',array('conditions'=>array('Customer.Type'=>'Supplier'))));
    }
    
    public function Warehouse_customer($id=null) {
        $this->Customer->id = $id;
        if (!$this->Customer->exists()) {
            throw new NotFoundException(__('Invalid Customer'));
        }
        $this->set('customerp', $this->Customer->read(null, $id));
        $this->set('purchases', $this->Purchase->find('all',array('conditions'=>array('Purchase.CustomerId'=>$id))));
        //$this->set('salesBalance', $this->BranchaSaleSummary->find('all',array('fields'=>array('sum(BranchaSaleSummary.Balance)as TotalBalance'),'conditions'=>array('BranchaSaleSummary.CustomerId'=>$id))));
        $this->set('prepurchases', $this->PrePurchase->find('all',array('conditions'=>array('PrePurchase.CustomerId'=>$id))));
        $this->set('prepurchasedelivery', $this->PrePurchase->find('all',array('conditions'=>array('PrePurchase.CustomerId'=>$id, 'PrePurchase.Status'=>'Not Delivered'))));
    }
    
    
}
?>