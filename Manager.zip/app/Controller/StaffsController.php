<?php
// app/controller/StaffsController

App::uses('AppController','Controller');

class StaffsController extends AppController {
    
    public function userRedirect(){
        $user = $this->Auth->user();
                if($user['Office']==='Warehouse'){
                    return $this->redirect(
                        array('Warehouse'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchA'){
                    return $this->redirect(
                        array('BranchA'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }else if($user['Office']==='BranchB'){
                    return $this->redirect(
                        array('BranchB'=>true, 'controller'=>'users', 'action'=>'dashboard')
                    );
                }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $router = Router::parse(Router::normalize(Router::url()));
        $user = $this->Auth->user();
        if(!($user['Office']==$router['prefix'])){
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                Warning! Invalid Access Area.'), 'default', array('class'=>'alert alert-warning')
            );
            $this->userRedirect();
        }
    }
    
    // **BranchA ...
    
    public function BranchA_add() {
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Staff->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Staff has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'Staff', $this->Staff->getLastInsertId()));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Staff could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function BranchA_edit($id=null) {
        $this->Staff->id = $id;
        if (!$this->Staff->exists()) {
            throw new NotFoundException(__('Invalid Staff'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Staff->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Staff has been Edited.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Staff could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->Staff->read(null, $id);
        }
    }
    
    public function BranchA_view() {
        $this->set('Staffs', $this->Staff->find('all',array('conditions'=>array('Staff.Type'=>'Buyer'))));
    }
    
    // **BranchB ...
    
    public function BranchB_add() {
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Staff->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Staff has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'Staff', $this->Staff->getLastInsertId()));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Staff could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function BranchB_edit($id=null) {
        $this->Staff->id = $id;
        if (!$this->Staff->exists()) {
            throw new NotFoundException(__('Invalid Staff'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Staff->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Staff has been Edited.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Staff could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->Staff->read(null, $id);
        }
    }
    
    public function BranchB_view() {
        $this->set('Staffs', $this->Staff->find('all',array('conditions'=>array('Staff.Type'=>'Buyer'))));
    }
    
    // Wharehouse ...
    
    public function Warehouse_add() {
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Staff->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Staff has been created.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'add'));
                                                                                
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Staff could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        }
    }
    
    public function Warehouse_edit($id=null) {
        $this->Staff->id = $id;
        if (!$this->Staff->exists()) {
            throw new NotFoundException(__('Invalid Staff'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Staff->save($this->request->data)) {
                $this->Session->setFlash(__('<button type="button" class="close" data-dismiss="alert">&times;</button>
                <b>Success.</b> The Staff has been Edited.'),'default', array('class'=>'alert alert-success'));
                return $this->redirect(array('action' => 'view'));
            }
            $this->Session->setFlash(
                __('<button type="button" class="close" data-dismiss="alert">&times;</button>
                The Staff could not be saved. Please, try again.'), 'default', array('class'=>'alert alert-error')
            );
        } else {
            $this->request->data = $this->Staff->read(null, $id);
        }
    }
    
    public function Warehouse_view() {
        $this->set('Staffs', $this->Staff->find('all'));
    }
    
    
}
?>