$(document).ready(function(e){
   alert('ready');
   $('#registered div').hide();
   $('#walkin div').hide();
   $('#voucher').hide();
   
   
   $('#customer').change(function(){
    if($(this).val() == 'registered'){
        $('#registered div').toggle();
        $('#registered div .form-control').attr('disabled',false);
        $('#walkin div').hide();
        $('#walkin div .form-control').attr('disabled',true);
    }else if($(this).val() == 'walkin'){
        $('#registered div').hide();
        $('#registered div .form-control').attr('disabled',true);
        $('#walkin div').toggle();
        $('#walkin div .form-control').attr('disabled',false);
    }else{
        $('#registered div').hide();
        $('#registered div .form-control').attr('disabled',true);
        $('#walkin div').hide();
        $('#walkin div .form-control').attr('disabled',true);
    }
   }); 
   

   // Ajax Calls
   $("#product").bind("change", function (event) {
    $.ajax({
        async:true, 
        data:$("#product").serialize(), 
        dataType:"html", 
        success:function (data, textStatus) {
            $("#ItemPrice").val(data);
            $("#ItemPrice").change();
            ;}, 
        type:"post", 
        url:"\/OfficeSuite\/quotations\/ajax_price_list"
        });
     return false;
    });
    
    $("#catg").bind("change", function (event) {
        $("#loader").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#catg").serialize(), 
             dataType:"html", 
             success:function (data, textStatus) {
                 $("#accs").html(data);
                 $("#loader").html('');
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/products\/ajax_product_list"
             });
     return false;
    });
    
    $("#accs").bind("change", function (event) {
        $("#loader").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#accs").serialize(), 
             dataType:"html", 
             success:function (data, textStatus) {
                 $("#btch").html(data);
                 $("#loader").html('');
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/products\/ajax_batch_list"
             });
     return false;
    });
    
    $("#catgPOS").bind("change", function (event) {
        $("#loaderPOS").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#catgPOS").serialize(), 
             dataType:"html", 
             success:function (data, textStatus) {
                 $("#accsPOS").html(data);
                 $("#btchPOS").html('');
                 $("#btchQnty").val('');
                 $("#AccPrice").val('');
                 $("#loaderPOS").html('');
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/products\/ajax_product_list"
             });
     return false;
    });
    
    $("#accsPOS").bind("change", function (event) {
        $("#loaderPOS").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#accsPOS").serialize(), 
             dataType:"html", 
             success:function (data, textStatus) {
                 $("#btchPOS").html(data);
                 $("#btchQnty").val('');
                 $("#AccPrice").val('');
                 $("#loaderPOS").html('');
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/sales\/ajax_batch_list"
             });
     return false;
    });
    
    $("#btchPOS").bind("change", function (event) {
        $("#loaderPOS").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#btchPOS").serialize(), 
             dataType:"json", 
             success:function (data, textStatus) {
                 $("#btchQnty").val(data.Quantity);
                 $("#AccPrice").val(data.Price);
                 $("#loaderPOS").html('');
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/sales\/ajax_batch"
             });
     return false;
    });
    
   
   // Calculate Item amount....
    $('#items').on('change',"#item .ItemQuantity",(function(e){
        var calcc = $(this).parents("#item").find(".ItemPrice").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    
    $('#items').on('change',"#item .ItemPrice",(function(e){
        var calcc = $(this).parents("#item").find(".ItemQuantity").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    
    $('#items').on('keyup',"#item .ItemQuantity",(function(e){
        var calcc = $(this).parents("#item").find(".ItemPrice").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    
    $('#items').on('keyup',"#item .ItemPrice",(function(e){
        var calcc = $(this).parents("#item").find(".ItemQuantity").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    // ! Item amounts.
    
    
    $("#AccQnty").change(function(e){
        var calcc = $("#AccPrice").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    $("#AccPrice").change(function(e){
        var calcc = $("#AccQnty").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    $("#AccQnty").keyup(function(e){
        var calcc = $("#AccPrice").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    $("#AccPrice").keyup(function(e){
        var calcc = $("#AccQnty").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    
    function subtot(){
        var subt = 0;
        var amt = document.getElementsByClassName("ItemAmount");
        for(e=0;e<amt.length;e++){
         subt = subt + parseInt(amt.item(e).value);   
        }
        return subt;
    }
        
    $('#items').on('change',"#item .ItemAmount",(function(e){        
        $("#subt").html(subtot());
        $("#total").val(subtot());
        $("#subt").change();
    }));
    
    $('#AmountPaid').keyup(function(e){
        $('#Balance').val($('#total').val() - $(this).val());
        if($('#Balance').val()>0){
            $('#Status').val('Credit');
        }else{
            $('#Status').val('Paid');
        }
    });
    
    var c = 1;
    $("#addbt").click(function(e){
        if($('#accs').val() == null || $('#accs').val() == ''){
                alert('Please Select Item');
            }else {
                c++;
                sel = $('#accs option:selected').html();
                var i = '<tr class="deletebtn" id="item" data-id="'+c+'">';
                i += '<td><input type="hidden" name="data[Item]['+c+'][Product_id]" value="'+$('#accs').val()+'" /><input type="hidden" name="data[Item]['+c+'][Batch_id]" value="'+$("#btch").val()+'" /><strong>'+sel+'</strong></td>'+                
                '<td> <input type="text" name="data[Item]['+c+'][Quantity]" class="form-control-sm ItemQuantity" value="'+$('#AccQnty').val()+'" required="required" /></td> '+ 
                '<td> <input type="text" name="data[Item]['+c+'][Price]" class="form-control-sm ItemPrice" value="'+$('#AccPrice').val()+'" required="required" /></td>'+
                '<td> <input name="data[Item]['+c+'][Amount]" class="form-control-sm ItemAmount" value="'+$('#AccAmt').val()+'" readonly="readonly" required="required" type="text" id="Item1Amount"/></td>'+ 
                '<td> <button type="button" class="deletebtn btn btn-sm btn-danger" id="deletebtn"><i class="fa fa-minus"></i></button></td></tr>';
                var it = $('#items').html();
                $(i).appendTo('#items');
                $('#item .ItemAmount').change();
            }
    });
    
    $("#addbtPOS").click(function(e){
        if($('#btchPOS').val() == null || $('#btchPOS').val() == ''){
                alert('Please Select Batch');
            }else {
                c++;
                sel = $('#accsPOS option:selected').html();
                var i = '<tr class="deletebtn" id="item" data-id="'+c+'">';
                i += '<td><input type="hidden" name="data[Item]['+c+'][Product_id]" value="'+$('#accsPOS').val()+'" /><input type="hidden" name="data[Item]['+c+'][Batch_id]" value="'+$("#btchPOS").val()+'" /><strong>'+sel+'</strong></td>'+                
                '<td> <input type="text" name="data[Item]['+c+'][Quantity]" class="form-control input-sm ItemQuantity" value="'+$('#AccQnty').val()+'" required="required" max="'+$('#btchQnty').val()+'" /></td> '+ 
                '<td> <input type="text" name="data[Item]['+c+'][Price]" class="form-control input-sm ItemPrice" readonly="readonly" value="'+$('#AccPrice').val()+'" required="required" /></td>'+
                '<td> <input name="data[Item]['+c+'][Amount]" class="form-control input-sm ItemAmount" value="'+$('#AccAmt').val()+'" readonly="readonly" required="required" type="text" id="Item1Amount"/></td>'+ 
                '<td> <button type="button" class="deletebtn btn btn-sm btn-danger" id="deletebtn"><i class="fa fa-minus"></i></button></td></tr>';
                var it = $('#items').html();
                $(i).appendTo('#items');
                $('#item .ItemAmount').change();
            }
    });
    
    $('#items').on('click','#deletebtn',(function(e) {
            var tri = $(this).closest('tr');
            var id = tri.data('id');
            var tot = tri.find('.totalPrice').val();
            amt = parseInt($('#SaleTotalAmount').val()) - tot;
            $('#SaleTotalAmount').val(amt)
            $('[data-id=' + id + ']').remove();
            $("#subt").html(subtot());
            $('#item .ItemAmount').change();
            
        }));
     
     
// Purchases ...   
    $("#PurchaseQuantity").change(function(e) {
        $("#PurchaseTotal").val($(this).val() * $("#PurchaseUnitPrice").val());
    })
                            
    $("#PurchaseUnitPrice").change(function(e) {
        $("#PurchaseTotal").val($(this).val() * $("#PurchaseQuantity").val());
    })
    
    $("#PurchaseQuantity").keyup(function(e) {
        $("#PurchaseTotal").val($(this).val() * $("#PurchaseUnitPrice").val());
    })
                            
    $("#PurchaseUnitPrice").keyup(function(e) {
        $("#PurchaseTotal").val($(this).val() * $("#PurchaseQuantity").val()); 
    })
    
    $("#noExp").click(function(e){
        if($(this).is(':checked')){
            $("#ExpD > select").attr('disabled', 'disabled');
        }else if(!($(this).is(':checked'))){
            alert($("#ExpD > select"))
            $("#ExpD > select").attr('disabled', 'enabled');
        }
    })
    // !- Purchases.        
// Sale Reciept
    $('#method').change(function(){
        if($(this).val() == 'Voucher'){
            $('#voucher').show();
            $('#token').attr('disabled',true);
        }else{
            $('#voucher').hide();
            $('#token').attr('disabled',false);
        }
    })

});


