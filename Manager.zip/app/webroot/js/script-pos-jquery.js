$(document).ready(function(e){
   alert('ready');
   $('body').addClass('sidebar-collapse');
   $('#productCode').focus();
   
   function resetForm(){
        $("#catgPOS").val('');
        $("#accsPOS").html('');
        $("#btchPOS").html('');
        $("#btchQnty").val('');
        $("#AccPrice").val('');
        $("#AccQnty").val('');
        $("#AccAmt").val('');
   }

   // Ajax Calls    
    $("#catgPOS").bind("change", function (event) {
        $("#loaderPOS").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#catgPOS").serialize(), 
             dataType:"html", 
             success:function (data, textStatus) {
                 $("#accsPOS").html(data);
                 $("#loaderPOS").html('');
                 $("#btchPOS").html('');
                 $("#btchQnty").val('');
                 $("#AccPrice").val('');
                 $("#AccQnty").val('');
                 $("#AccAmt").val('');                
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/products\/ajax_product_list"
             });
     return false;
    });
    
    $("#accsPOS").bind("change", function (event) {
        $("#loaderPOS").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#accsPOS").serialize(), 
             dataType:"html", 
             success:function (data, textStatus) {
                 $("#btchPOS").html(data);
                 $("#loaderPOS").html('');
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/sales\/ajax_batch_list"
             });
     return false;
    });
    
    $("#btchPOS").bind("change", function (event) {
        $("#loaderPOS").html('<i class="fa fa-spinner fa-spin"></i>');
     $.ajax({
             async:true, 
             data:$("#btchPOS").serialize(), 
             dataType:"json", 
             success:function (data, textStatus) {
                 $("#btchQnty").val(data.Quantity);
                 $("#AccPrice").val(data.Price);
                 $("#loaderPOS").html('');
                 },
             error:function (xhr, textStatus, data) {
                alert('error: '+data);
                 }, 
             type:"post",
             url:"\/cakephp-cakephp-2.4.9\/sales\/ajax_batch"
             });
     return false;
    });
    
   
   // Calculate Item amount....
    $('#items').on('change',"#item .ItemQuantity",(function(e){
        var calcc = $(this).parents("#item").find(".ItemPrice").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    
    $('#items').on('change',"#item .ItemPrice",(function(e){
        var calcc = $(this).parents("#item").find(".ItemQuantity").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    
    $('#items').on('keyup',"#item .ItemQuantity",(function(e){
        var calcc = $(this).parents("#item").find(".ItemPrice").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    
    $('#items').on('keyup',"#item .ItemPrice",(function(e){
        var calcc = $(this).parents("#item").find(".ItemQuantity").val() * $(this).val();
        $(this).parents("#item").find(".ItemAmount").val(calcc);
        $(this).parents("#item").find(".ItemAmount").change();
    }));
    // ! Item amounts.
    
    
    $("#AccQnty").change(function(e){
        var calcc = $("#AccPrice").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    $("#AccPrice").change(function(e){
        var calcc = $("#AccQnty").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    $("#AccQnty").keyup(function(e){
        var calcc = $("#AccPrice").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    $("#AccPrice").keyup(function(e){
        var calcc = $("#AccQnty").val() * $(this).val();
        $("#AccAmt").val(calcc);        
    });
    
    
    function subtot(){
        var subt = 0;
        var amt = document.getElementsByClassName("ItemAmount");
        for(e=0;e<amt.length;e++){
         subt = subt + parseInt(amt.item(e).value);   
        }
        return subt;
    }
        
    $('#items').on('change',"#item .ItemAmount",(function(e){        
        $("#subt").html(subtot());
        $("#total").val(subtot());
    }));
    
    var c = 1;    
    $("#addbtPOS").click(function(e){
        if($('#btchPOS').val() == null || $('#btchPOS').val() == ''){
                alert('Please Select Batch');
            }else {
                c++;
                sel = $('#accsPOS option:selected').html();
                var i = '<tr class="deletebtn" id="item" data-id="'+c+'">';
                i += '<td><input type="hidden" name="data[Item]['+c+'][Product_id]" value="'+$('#accsPOS').val()+'" /><input type="hidden" name="data[Item]['+c+'][Batch_id]" value="'+$("#btchPOS").val()+'" /><strong>'+sel+'</strong></td>'+                
                '<td> '+$('#btchQnty').val()+' </td> '+
                '<td> <input type="text" name="data[Item]['+c+'][Quantity]" class="form-control input-sm ItemQuantity" value="'+$('#AccQnty').val()+'" required="required" max="'+$('#btchQnty').val()+'" /></td> '+                
                '<td> <input type="text" name="data[Item]['+c+'][Price]" class="form-control input-sm ItemPrice" readonly="readonly" value="'+$('#AccPrice').val()+'" required="required" /></td>'+
                '<td> <input name="data[Item]['+c+'][Amount]" class="form-control input-sm ItemAmount" value="'+$('#AccAmt').val()+'" readonly="readonly" required="required" type="text" id="Item1Amount"/></td>'+ 
                '<td> <button type="button" class="deletebtn btn btn-sm btn-danger" id="deletebtn"><i class="fa fa-minus"></i></button></td></tr>';
                var it = $('#items').html();
                $(i).appendTo('#items');
                $('#item .ItemAmount').change();
                resetForm();
            }
    });
    
    $('#items').on('click','#deletebtn',(function(e) {
            var tri = $(this).closest('tr');
            var id = tri.data('id');
            $('[data-id=' + id + ']').remove();
            $("#subt").html(subtot());
            $('#total').val(subtot());
            
        }));
                
// Sale Reciept
    $('#method').change(function(){
        if($(this).val() == 'Voucher'){
            $('#voucher').show();
            $('#token').attr('disabled',true);
        }else{
            $('#voucher').hide();
            $('#token').attr('disabled',false);
        }
    });
    
    // Clock
    setInterval(function updateClock ( )
 	{
 	var currentTime = new Date ( );
  	var currentHours = currentTime.getHours ( );
  	var currentMinutes = currentTime.getMinutes ( );
  	var currentSeconds = currentTime.getSeconds ( );

  	// Pad the minutes and seconds with leading zeros, if required
  	currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  	currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

  	// Choose either "AM" or "PM" as appropriate
  	var timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

  	// Convert the hours component to 12-hour format if needed
  	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

  	// Convert an hours component of "0" to "12"
  	currentHours = ( currentHours == 0 ) ? 12 : currentHours;

  	// Compose the string for display
  	var currentTimeString = currentHours + ":" + currentMinutes + ":" + currentSeconds + " " + timeOfDay;
  	
  	
   	$("#time").html(currentTimeString);
   	  	
 }, 1000);

});


