$('document').ready(function(){
    $(function () {

        /*
         * BAR CHART
         * ---------
         */
        
        // Bar Chart 1
        var bar_data = {
          data: [["Sales Amount", $('#SItemAmount').html()], ["Sales Profit", $('#SItemProfit').html()]],
          color: "#3c8dbc"
        };
        $.plot("#bar-chart", [bar_data], {
          grid: {
            borderWidth: 0.5,
            borderColor: "#f3f3f3",
            tickColor: "#f3f3f3"
          },
          series: {
            bars: {
              show: true,
              barWidth: 0.5,
              align: "center"
            }
          },
          xaxis: {
            mode: "categories",
            tickLength: 0
          }
        });
        
        // Bar Chart 2
        var bar_data2 = {
          data: [["Sales Payment", $('#Spayment').html()], ["Expences", $('#Expence').html()]],
          color: "#3c8dbc"
        };
        $.plot("#bar-chart-cash", [bar_data2], {
          grid: {
            borderWidth: 0.5,
            borderColor: "#f3f3f3",
            tickColor: "#f3f3f3"
          },
          series: {
            bars: {
              show: true,
              barWidth: 0.5,
              align: "center"
            }
          },
          xaxis: {
            mode: "categories",
            tickLength: 0
          }
        });
        
        /* END BAR CHART */

        /*
         * DONUT CHART
         * -----------
         */

        var donutData = [
          {label: "Paid Amount", data: $('#Samount').html(), color: "#3c8dbc"},
          {label: "Unpaid Balance", data: $('#Sbalance').html(), color: "#0073b7"}
        ];
        $.plot("#donut-chart-sales", donutData, {
          series: {
            pie: {
              show: true,
              radius: 1,
              innerRadius: 0.05,
              label: {
                show: true,
                radius: 1 / 2,
                formatter: labelFormatter,
                threshold: 0.1
              }

            }
          },
          legend: {
            show: false
          }
        });
        
        // Donut Chart 2
        var donutData2 = [
          {label: "Cash", data: $('#Spaymentcash').html(), color: "#3c8dbc"},
          {label: "Bank", data: $('#Spaymentbank').html(), color: "#0073b7"},
          {label: "Voucher", data: $('#Spaymentvoucher').html(), color: "#0073a2"}
        ];
        $.plot("#donut-chart-payment", donutData2, {
          series: {
            pie: {
              show: true,
              radius: 1,
              innerRadius: 0.05,
              label: {
                show: true,
                radius: 1 / 2,
                formatter: labelFormatter,
                threshold: 0.1
              }

            }
          },
          legend: {
            show: false
          }
        });
        /*
         * END DONUT CHART
         */

      });

      /*
       * Custom Label formatter
       * ----------------------
       */
      function labelFormatter(label, series) {
        return "<div style='font-size:12px; text-align:center; padding:2px; color: #fff; font-weight: 600;'>"
                + label
                + "<br/>"
                + Math.round(series.percent) + "%</div>";
      }
})