<?php
// app/Model/Product.php

App::uses('AppModel', 'Model');

    
class Product extends AppModel {
    
    public $belongsTo = array(
        'ProductCategory' => array(
            'className' => 'ProductCategory',
            'foreignKey' => 'Category_id'
        )        
    );
    
    public $hasMany = array(
        'Batch' => array(
            'className' => 'Batch',
            'foreignKey' => 'Product_id'
        )  
    );
    
}
?>