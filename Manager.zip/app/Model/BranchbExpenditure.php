<?php
// app/Model/Branchb_Expenditure.php

App::uses('AppModel', 'Model');

    
class BranchbExpenditure extends AppModel {
    
    
    
}
?>