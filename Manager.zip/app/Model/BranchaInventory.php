<?php
// app/Model/Brancha_Inventory.php

App::uses('AppModel', 'Model');

    
class BranchaInventory extends AppModel {
    
    public $belongsTo = array(
        'Product' => array(
            'className' => 'Product',
            'foreignKey' => 'Product_id'
        ),
        'Batch' => array(
            'className' => 'Batch',
            'foreignKey' => 'Batch_id'
        )        
    );
    
}
?>