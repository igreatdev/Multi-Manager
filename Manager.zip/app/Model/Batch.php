<?php
// app/Model/Batch.php

App::uses('AppModel', 'Model');

    
class Batch extends AppModel {
    
    public $belongsTo = array(
        'Product' => array(
            'className' => 'Product',
            'foreignKey' => 'Product_id'
        )
    );
    
}
?>