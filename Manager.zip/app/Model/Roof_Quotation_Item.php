<?php
// app/Model/Return_Purchase.php

App::uses('AppModel', 'Model');

    
class RoofQuotationItem extends AppModel {
    
    
    
}
?>