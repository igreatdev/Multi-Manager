<?php
// app/Model/Brancha_Sale_Item.php

App::uses('AppModel', 'Model');

    
class BranchaSaleItem extends AppModel {
    public $validate = array(
        'Date'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Date is required'
                )
            ),
        'Item'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Buyer is required'
                )
            ),
        'InvoiceNo'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Reciept is required'
                )
            )
    );
    
    public $belongsTo = array(
        'Product' => array(
            'className' => 'Product',
            'foreignKey' => 'Product_id'
        )        
    ); 
    
    
}
?>