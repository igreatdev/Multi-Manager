<?php
// app/Model/Batch.php

App::uses('AppModel', 'Model');

    
class Quotation extends AppModel {
    public $belongsTo = array('Product'=>array('className'=>'Product', 'foreignKey'=>'ProductId'));
    public $validate = array(
        'BatchNo'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Batch No is required'
                )
            ),
        'ProductId'=>array(
            'valid'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Product is required'
                )
            ),
        'ProductionDate'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Production Date is required'
                )
            ),
        'ExpiringDate'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Expiring Date is required'
                )
            )
    );
    
    
}
?>