<?php
// app/Model/Brancha_Expenditure.php

App::uses('AppModel', 'Model');

    
class BranchaExpenditure extends AppModel {
    
    
    
}
?>