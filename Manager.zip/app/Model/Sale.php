<?php
// app/Model/Sale.php

App::uses('AppModel', 'Model');

    
class Sale extends AppModel {
    public $validate = array(
        'Date'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Date is required'
                )
            ),
        'Buyer'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Buyer is required'
                )
            )
    );
    
    
}
?>