<?php
// app/Model/Brancha_Inventory.php

App::uses('AppModel', 'Model');

    
class BranchbInventory extends AppModel {
    
    
    
}
?>