<?php
// app/Model/Pre_Purchaes.php

App::uses('AppModel', 'Model');

    
class PrePurchase extends AppModel {
    
    
    
}
?>