<?php
// app/Model/Purchaes.php

App::uses('AppModel', 'Model');

    
class Purchase extends AppModel {
    
    public $validate = array(
        'Batch_id'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Batch is required'
                )
            ),
        'Quantity'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Quantity is required'
                )
            ),
        'UnitPrice'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'UnitPrice is required'
                )
            ),
        'Total'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Total is required'
                )
            )
    );
    
}
?>