<?php
// app/Model/Brancha_Sale_Summary.php

App::uses('AppModel', 'Model');

    
class BranchaSaleSummary extends AppModel {
    public $validate = array(
        'Date'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Date is required'
                )
            ),
        'Buyer'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Buyer is required'
                )
            ),
        'InvoiceNo'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Reciept is required'
                )
            ),
        'PhoneNo'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Phone No is required'
                )
            )
    );
    
    
}
?>