<?php
// app/Model/Returned_Saleitem.php

App::uses('AppModel', 'Model');

    
class BranchaReturnedSaleitem extends AppModel {
    
    
    
}
?>