<?php
// app/Model/Sale.php

App::uses('AppModel', 'Model');

    
class BranchaSalePayment extends AppModel {
    public $validate = array(
        'Date'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Date is required'
                )
            ),
        'AmountPaid'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Amount Paid is required'
                )
            )
    );
    
    
}
?>