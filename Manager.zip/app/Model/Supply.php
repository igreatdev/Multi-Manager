<?php
// app/Model/Supply.php

App::uses('AppModel', 'Model');

    
class Supply extends AppModel {
    
    
    
}
?>