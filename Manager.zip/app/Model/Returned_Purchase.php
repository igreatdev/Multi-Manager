<?php
// app/Model/Returned_Purchaes.php

App::uses('AppModel', 'Model');

    
class ReturnedPurchase extends AppModel {
    
    
    
}
?>