<?php
// app/Model/Voucher.php

App::uses('AppModel', 'Model');

    
class Voucher extends AppModel {
    
    
    
}
?>