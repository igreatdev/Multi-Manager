<?php
// app/Model/Product_Category.php

App::uses('AppModel', 'Model');

    
class ProductCategory extends AppModel {
    
    public $hasMany = array(
        'Produc' => array(
            'className' => 'Product',
            'foreignKey' => 'Category_id'
        )
    );
    
}
?>