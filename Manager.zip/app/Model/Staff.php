<?php
// app/Model/Staff.php

App::uses('AppModel', 'Model');

    
class Staff extends AppModel {
    public $validate = array(
        'Name'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Name is required'
                )
            ),
        'Gender'=>array(
            'valid'=>array(
                'rule' => array('inList', array('Male','Female')),
                'message' => 'Please enter a valid gender',
                'allowEmpty' => false
                )
            ),
        'JobDescription'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'JobDescription is required'
                )
            ),
        'Bank'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Bank is required'
                )
            ),
        'AcountNumber'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'AcountNumber is required'
                )
            )
    );
    
    
}
?>