<?php
// app/Model/Returned_Supply.php

App::uses('AppModel', 'Model');

    
class ReturnedSupply extends AppModel {
    
    
    
}
?>