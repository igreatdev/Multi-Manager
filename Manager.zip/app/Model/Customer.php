<?php
// app/Model/Customer.php

App::uses('AppModel', 'Model');

    
class Customer extends AppModel {
    public $validate = array(
        'Name'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Name is required'
                )
            ),
        'Address'=>array(
            'required'=>array(
                'rule' => array('notEmpty'),
                'message' => 'Address is required'
                )
            ),
        'Type'=>array(
            'valid'=>array(
                'rule' => array('inList', array('Supplier','Buyer')),
                'message' => 'Please enter a valid type',
                'allowEmpty' => false
                )
            )
    );
    
    
}
?>